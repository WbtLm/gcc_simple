//
//  assemblylan.h
//  asslan
//
//  Created by dawn on 2020/2/25.
//  Copyright © 2020 chuyi. All rights reserved.
//

#ifndef assemblylan_h
#define assemblylan_h
int assemblylan(std::string filepath);
#endif /* assemblylan_h */
