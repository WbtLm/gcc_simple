
int var;
int mmm=3;
void func(int a){
    var=90+mmm*a;
    return ;
}
int main(){
    int a=1;
    int b;
    if(a==b){
        
        
    }
    else{
        func(2);
    }
    
}
