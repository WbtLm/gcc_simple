//
//  background.hpp
//  test
//
//  Created by dawn on 2020/1/9.
//  Copyright © 2020 chuyi. All rights reserved.
//

#ifndef background_h
#define background_h

#include "macro.h"

string background(string code);
string get_debug_str();

#endif /* background_hpp== */
