//
//  data_type_func.cpp
//  gcc_simple
//
//  Created by dawn on 2020/4/6.
//  Copyright © 2020 chuyi. All rights reserved.
//

#include "data_type_func.h"
