//
//  struct_type_dic.cpp
//  gcc_simple
//
//  Created by dawn on 2020/3/24.
//  Copyright © 2020 chuyi. All rights reserved.
//

#include "struct_type_dic.h"
struct_type_dic* struct_type_dic::impl=NULL;
